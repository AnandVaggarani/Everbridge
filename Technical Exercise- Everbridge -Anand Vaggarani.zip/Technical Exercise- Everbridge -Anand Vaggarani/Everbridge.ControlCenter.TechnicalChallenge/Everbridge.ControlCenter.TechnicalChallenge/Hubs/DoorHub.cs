﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR;

namespace Everbridge.ControlCenter.TechnicalChallenge.Hubs
{
    public class DoorHub : Hub
    {
    }
}
