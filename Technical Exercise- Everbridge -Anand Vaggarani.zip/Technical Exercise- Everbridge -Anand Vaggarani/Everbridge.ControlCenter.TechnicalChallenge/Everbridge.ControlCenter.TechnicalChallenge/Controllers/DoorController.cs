﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Everbridge.ControlCenter.TechnicalChallenge.DoorDatabase;
using Everbridge.ControlCenter.TechnicalChallenge.Hubs;
using Everbridge.ControlCenter.TechnicalChallenge.Models;
using Microsoft.AspNetCore.SignalR;

namespace Everbridge.ControlCenter.TechnicalChallenge.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Produces("application/json")]
    public class DoorController : ControllerBase
    {
        private readonly ILogger<DoorController> _logger;
        private readonly DoorRepositoryService _doorRepositoryService;
        private readonly IHubContext<DoorHub> _doorHubContext;

        public DoorController(ILogger<DoorController> logger, DoorRepositoryDatabaseContext databaseContext, IHubContext<DoorHub> doorHubContext)
        {
            _logger = logger;
            _doorRepositoryService = new DoorRepositoryService(databaseContext);
            _doorHubContext = doorHubContext;
        }

        [HttpGet]
        public async Task<IEnumerable<string>> Get()
        {
            return await _doorRepositoryService.GetDoorsIds();
        }

        [HttpGet]
        [Route("{doorId}")]
        public async Task<DoorModel> GetDoor([FromRoute] [Required] string doorId)
        {
            var doorRecord = await _doorRepositoryService.GetDoor(doorId);

            return (doorRecord == null)
                ? null
                : new DoorModel
                {
                    Id = doorRecord.Id,
                    Label = doorRecord.Label,
                    IsOpen = doorRecord.IsOpen,
                    IsLocked = doorRecord.IsLocked
                };
        }

        [HttpPost]
        public async Task<DoorModel> AddDoor([FromBody] [Required] DoorModel doorModel)
        {
            var doorRecordDto = new DoorRecordDto
            {
                Label = doorModel.Label,
                IsLocked = doorModel.IsLocked,
                IsOpen = doorModel.IsOpen
            };

            var doorRecord = await _doorRepositoryService.AddDoor(doorRecordDto);

            if (doorRecord == null)
            {
                return null;
            }

            await _doorHubContext.Clients.All.SendAsync("DoorAdded", doorRecord.Id);

            return new DoorModel
            {
                Id = doorRecord.Id,
                Label = doorRecord.Label,
                IsOpen = doorRecord.IsOpen,
                IsLocked = doorRecord.IsLocked
            };
        }

        [HttpPut]
        public async Task<DoorModel> UpdateDoor([FromBody][Required] DoorModel doorModel)
        {
            var doorRecordDto = new DoorRecordDto
            {
                Id = doorModel.Id,
                Label = doorModel.Label,
                IsLocked = doorModel.IsLocked,
                IsOpen = doorModel.IsOpen
            };

            var doorRecord = await _doorRepositoryService.UpdateDoor(doorRecordDto);

            if (doorRecord == null)
            {
                return null;
            }

            await _doorHubContext.Clients.All.SendAsync("DoorUpdated", doorRecord);

            return new DoorModel
            {
                Id = doorRecord.Id,
                Label = doorRecord.Label,
                IsOpen = doorRecord.IsOpen,
                IsLocked = doorRecord.IsLocked
            };
        }

        [HttpDelete]
        [Route("{doorId}")]
        public async Task<DoorModel> RemoveDoor([FromRoute][Required] string doorId)
        {
            var doorRecord = await _doorRepositoryService.RemoveDoor(doorId);

            if (doorRecord == null)
            {
                return null;
            }

            await _doorHubContext.Clients.All.SendAsync("DoorRemoved", doorRecord.Id);

            return new DoorModel
            {
                Id = doorRecord.Id,
                Label = doorRecord.Label,
                IsOpen = doorRecord.IsOpen,
                IsLocked = doorRecord.IsLocked
            };
        }
    }
}
