﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Input;
using DoorManagementSystem.Model;
using DoorManagementSystem.ViewModel.Commands;

namespace DoorManagementSystem.ViewModel
{
    public class DoorViewModel : INotifyPropertyChanged
    {
        private readonly DoorModel _model;

        #region ctor

        public DoorViewModel()
        {
            _model = new DoorModel();
            _door = new DoorModel();
            AddDoorCommand = new AddDoorCommand(_model);
            ViewDoorCommand = new ViewDoorCommand(this, _model);
            UpdateDoorCommand = new UpdateDoorCommand(_model);
            RemoveDoorCommand = new RemoveDoorCommand( _model);
        }

        #endregion

        #region Properties

        #region Door

        private DoorModel _door;

        public DoorModel Door
        {
            get => _door;
            set
            {
                _door = value;
                NotifyPropertyChanged(nameof(Door));
            }
        }

        #endregion

        #region Doors

        public ObservableCollection<string> Doors
        {
            get => _model.Ids;
            set => _model.Ids = value;
        }


        #endregion

        #region Coomands

        public AddDoorCommand AddDoorCommand { get; set; }

        public ICommand ViewDoorCommand { get; set; }

        public UpdateDoorCommand UpdateDoorCommand { get; set; }

        public RemoveDoorCommand RemoveDoorCommand { get; set; }

        #endregion

        #endregion

        #region INotifyPropertyChanged Implementation

        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion
    }
}
