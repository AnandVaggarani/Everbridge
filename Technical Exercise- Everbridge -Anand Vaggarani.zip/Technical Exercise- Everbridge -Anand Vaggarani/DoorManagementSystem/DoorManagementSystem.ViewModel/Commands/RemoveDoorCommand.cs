﻿using System;
using System.Windows.Input;
using DoorManagementSystem.Model;

namespace DoorManagementSystem.ViewModel.Commands
{
    public class RemoveDoorCommand : ICommand
    {
        private readonly DoorModel _doorModel;

        public event Action DoorRemoved;

        public RemoveDoorCommand(DoorModel doorModel)
        {
            _doorModel = doorModel;
        }

        public bool CanExecute(object parameter)
        {
            if (parameter == null)
                return false;

            var doorModelId = (string)parameter;
            if (string.IsNullOrEmpty(doorModelId))
                return false;

            return true;
        }

        public void Execute(object parameter)
        {
            var doorModelId = (string)parameter;
            var result = _doorModel.RemoveDoor(doorModelId).Result;

            DoorRemoved?.Invoke();
        }

        public event EventHandler CanExecuteChanged
        {
            add => CommandManager.RequerySuggested += value;
            remove => CommandManager.RequerySuggested -= value;
        }
    }
}

