﻿using System;
using System.Windows.Input;
using DoorManagementSystem.Model;

namespace DoorManagementSystem.ViewModel.Commands
{
    public class AddDoorCommand : ICommand
    {
        private readonly DoorModel _doorModel;

        public event Action DoorAdded;

        public AddDoorCommand(DoorModel doorModel)
        {
            _doorModel = doorModel;
        }

        public bool CanExecute(object parameter)
        {
            if (parameter == null)
                return false;

            var doorModel = (DoorModel)parameter;
            if (string.IsNullOrEmpty(doorModel.Label) || doorModel.IsOpen == null || doorModel.IsLocked == null)
                return false;

            return true;
        }

        public void Execute(object parameter)
        {
            var doorModel = (DoorModel) parameter;
            doorModel.Id = Guid.NewGuid().ToString();
            var result = _doorModel.AddDoor(doorModel).Result;

            DoorAdded?.Invoke();
        }

        public event EventHandler CanExecuteChanged
        {
            add => CommandManager.RequerySuggested += value;
            remove => CommandManager.RequerySuggested -= value;
        }
    }
}
