﻿using System;
using System.Windows.Input;
using DoorManagementSystem.Model;

namespace DoorManagementSystem.ViewModel.Commands
{
    public class ViewDoorCommand : ICommand
    {
        private readonly DoorViewModel _doorViewModel;
        private readonly DoorModel _doorModel;

        public ViewDoorCommand(DoorViewModel doorViewModel, DoorModel doorModel)
        {
            _doorViewModel = doorViewModel;
            _doorModel = doorModel;
        }

        public bool CanExecute(object parameter)
        {
            if (parameter == null)
                return false;

            var doorModelId = (string)parameter;
            if (string.IsNullOrEmpty(doorModelId))
                return false;

            return true;
        }

        public void Execute(object parameter)
        {
            var doorModelId = (string)parameter;
            var result = _doorModel.GetDoor(doorModelId).Result;

            _doorViewModel.Door.Id = result.Id;
            _doorViewModel.Door.Label = result.Label;
            _doorViewModel.Door.IsOpen = result.IsOpen;
            _doorViewModel.Door.IsLocked = result.IsLocked;
        }

        public event EventHandler CanExecuteChanged
        {
            add => CommandManager.RequerySuggested += value;
            remove => CommandManager.RequerySuggested -= value;
        }
    }
}

