﻿using Microsoft.AspNetCore.SignalR.Client;

namespace DoorManagementSystem.Model
{
    public class DoorHub
    {
        #region ctor

        public DoorHub(DoorModel doorModel)
        {
            var hubConnection = new HubConnectionBuilder().WithUrl("https://localhost:12443/DoorHub").Build();

            hubConnection.On<string>("DoorAdded", (doorId) =>
            {
                doorModel.Ids.Add(doorId);
            });

            hubConnection.On<DoorModel>("DoorUpdated", (record) =>
            {
                if (doorModel.Id.Equals(record.Id))
                {
                    doorModel.Id = record.Id;
                    doorModel.Label = record.Label;
                    doorModel.IsOpen = record.IsOpen;
                    doorModel.IsLocked = record.IsLocked;
                    doorModel.IsOpen = record.IsOpen;
                    doorModel.IsLocked = record.IsLocked;
                }
            });

            hubConnection.On<string>("DoorRemoved", (doorId) =>
            {
                doorModel.Ids.Remove(doorId);
                if (doorModel.Id.Equals(doorId))
                {
                    doorModel.Id = string.Empty;
                    doorModel.Label = string.Empty;
                    doorModel.IsOpen = null;
                    doorModel.IsLocked = null;
                }
            });

            hubConnection.StartAsync();
        }

        #endregion
    }
}
