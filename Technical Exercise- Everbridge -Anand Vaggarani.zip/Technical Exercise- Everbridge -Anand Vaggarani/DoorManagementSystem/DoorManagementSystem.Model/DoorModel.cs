﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Threading.Tasks;
using DoorManagementSystem.Service;
using Newtonsoft.Json;

namespace DoorManagementSystem.Model
{
    public class DoorModel : INotifyPropertyChanged
    {
        private readonly DoorService _doorService;
        private readonly DoorHub _doorHub;

        #region ctor

        public DoorModel()
        {
            _doorService = new DoorService();
            _doorHub = new DoorHub(this);

            Ids = GetDoorIds().Result;
        }

        #endregion

        #region Properties

        #region Id

        private string _id;

        public string Id
        {
            get => _id;
            set
            {
                _id = value;
                NotifyPropertyChanged(nameof(Id));
            }
        }

        #endregion

        #region Label

        private string _label;

        public string Label
        {
            get => _label;
            set
            {
                _label = value;
                NotifyPropertyChanged(nameof(Label));
            }
        }

        #endregion

        #region IsOpen

        private bool? _isOpen;

        public bool? IsOpen
        {
            get => _isOpen;
            set
            {
                if (_isLocked == true && value == true)
                {
                    return;
                }

                _isOpen = value;
                NotifyPropertyChanged(nameof(IsOpen));
            }
        }

        #endregion

        #region IsLocked

        private bool? _isLocked;

        public bool? IsLocked
        {
            get => _isLocked;
            set
            {
                if (_isOpen == true && value == true)
                {
                    return;
                }
                
                _isLocked = value;
                NotifyPropertyChanged(nameof(IsLocked));
            }
        }

        #endregion

        #region Ids

        private ObservableCollection<string> _ids;

        public ObservableCollection<string> Ids
        {
            get => _ids;
            set
            {
                _ids = value;
                NotifyPropertyChanged(nameof(Ids));
            }
        }


        #endregion

        #endregion

        #region INotifyPropertyChanged Implementation

        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion

        #region Remote Service Implementation

        public async Task<ObservableCollection<string>> GetDoorIds()
        {
            var response = await _doorService.GetAsync().ConfigureAwait(false);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                var value = JsonConvert.DeserializeObject<ObservableCollection<string>>(content);
                return value;
            }

            return null;
        }

        public async Task<DoorModel> GetDoor(string doorId)
        {
            var response = await _doorService.GetAsync(doorId).ConfigureAwait(false);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                var value = JsonConvert.DeserializeObject<DoorModel>(content);
                return value;
            }

            return null;
        }

        public async Task<DoorModel> AddDoor(DoorModel doorModel)
        {
            var body = JsonConvert.SerializeObject(doorModel);
            var response = await _doorService.PostAsync(body).ConfigureAwait(false);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                var value = JsonConvert.DeserializeObject<DoorModel>(content);
                return value;
            }

            return null;
        }

        public async Task<DoorModel> UpdateDoor(DoorModel doorModel)
        {
            var body = JsonConvert.SerializeObject(doorModel);
            var response = await _doorService.PutAsync(body).ConfigureAwait(false);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                var value = JsonConvert.DeserializeObject<DoorModel>(content);
                return value;
            }

            return null;
        }

        public async Task<DoorModel> RemoveDoor(string doorId)
        {
            var response = await _doorService.DeleteAsync(doorId).ConfigureAwait(false);
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                var value = JsonConvert.DeserializeObject<DoorModel>(content);
                return value;
            }

            return null;
        }

        #endregion
    }
}
