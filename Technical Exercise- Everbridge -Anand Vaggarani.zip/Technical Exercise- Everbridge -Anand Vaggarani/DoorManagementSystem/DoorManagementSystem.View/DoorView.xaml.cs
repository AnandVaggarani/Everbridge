﻿using System.Windows;
using DoorManagementSystem.ViewModel;

namespace DoorManagementSystem.View
{
    /// <summary>
    /// Interaction logic for DoorView.xaml
    /// </summary>
    public partial class DoorView : Window
    {
        public DoorView()
        {
            InitializeComponent();
            var viewModel = new DoorViewModel();
            DataContext = viewModel;
            viewModel.AddDoorCommand.DoorAdded += ViewModelOnDoorAdded;
            viewModel.UpdateDoorCommand.DoorUpdated += ViewModelOnDoorUpdated;
            viewModel.RemoveDoorCommand.DoorRemoved += ViewModelOnDoorRemoved;
        }

        private void ViewModelOnDoorAdded()
        {
            TextBoxDoorId.Text = string.Empty;

            TextBoxDoorId.IsEnabled = false;
            TextBoxDoorName.IsEnabled = false;
            CheckBoxDoorOpened.IsEnabled = false;
            CheckBoxDoorLocked.IsEnabled = false;

            ButtonAddNewDoor.Visibility = Visibility.Collapsed;
            ButtonViewDoor.Visibility = Visibility.Collapsed;
            ButtonUpdateDoor.Visibility = Visibility.Collapsed;
            ButtonDeleteDoor.Visibility = Visibility.Collapsed;

            ButtonAddDoor.Visibility = Visibility.Visible;
            TextBlockStatusMessage.Text = "New Door has been added.";
        }

        private void ViewModelOnDoorUpdated()
        {
            TextBoxDoorId.IsEnabled = false;
            TextBoxDoorName.IsEnabled = false;
            CheckBoxDoorOpened.IsEnabled = false;
            CheckBoxDoorLocked.IsEnabled = false;

            ButtonAddNewDoor.Visibility = Visibility.Collapsed;
            ButtonViewDoor.Visibility = Visibility.Collapsed;
            ButtonUpdateDoor.Visibility = Visibility.Collapsed;
            ButtonDeleteDoor.Visibility = Visibility.Collapsed;

            ButtonAddDoor.Visibility = Visibility.Collapsed;
            TextBlockStatusMessage.Text = "Door has been updated.";
        }

        private void ViewModelOnDoorRemoved()
        {
            TextBoxDoorId.IsEnabled = false;
            TextBoxDoorName.IsEnabled = false;
            CheckBoxDoorOpened.IsEnabled = false;
            CheckBoxDoorLocked.IsEnabled = false;

            ButtonAddNewDoor.Visibility = Visibility.Collapsed;
            ButtonViewDoor.Visibility = Visibility.Collapsed;
            ButtonUpdateDoor.Visibility = Visibility.Collapsed;
            ButtonDeleteDoor.Visibility = Visibility.Collapsed;

            ButtonAddDoor.Visibility = Visibility.Visible;
            TextBlockStatusMessage.Text = "Door has been removed.";
        }

        private void ReviewDoorClicked(object sender, RoutedEventArgs e)
        {
            TextBoxDoorId.Text = (string)DataGrid.CurrentCell.Item;
            TextBoxDoorName.Text = string.Empty;
            CheckBoxDoorOpened.IsChecked = null;
            CheckBoxDoorLocked.IsChecked = null;

            TextBoxDoorId.IsEnabled = false;
            TextBoxDoorName.IsEnabled = false;
            CheckBoxDoorOpened.IsEnabled = false;
            CheckBoxDoorLocked.IsEnabled = false;

            ButtonAddNewDoor.Visibility = Visibility.Collapsed;
            ButtonViewDoor.Visibility = Visibility.Collapsed;
            ButtonUpdateDoor.Visibility = Visibility.Collapsed;
            ButtonDeleteDoor.Visibility = Visibility.Collapsed;

            ButtonAddDoor.Visibility = Visibility.Collapsed;
            TextBlockStatusMessage.Text = "Door has been loaded.";

            var viewModel = (DoorViewModel)DataContext;
            viewModel.ViewDoorCommand.Execute(TextBoxDoorId.Text);
        }

        private void ConfigureDoorClicked(object sender, RoutedEventArgs e)
        {
            TextBoxDoorId.Text = (string)DataGrid.CurrentCell.Item;
            TextBoxDoorName.Text = string.Empty;
            CheckBoxDoorOpened.IsChecked = null;
            CheckBoxDoorLocked.IsChecked = null;

            TextBoxDoorId.IsEnabled = false;
            TextBoxDoorName.IsEnabled = false;
            CheckBoxDoorOpened.IsEnabled = false;
            CheckBoxDoorLocked.IsEnabled = false;

            ButtonAddNewDoor.Visibility = Visibility.Collapsed;
            ButtonViewDoor.Visibility = Visibility.Collapsed;
            ButtonUpdateDoor.Visibility = Visibility.Collapsed;
            ButtonDeleteDoor.Visibility = Visibility.Visible;

            ButtonAddDoor.Visibility = Visibility.Visible;
            TextBlockStatusMessage.Text = "Door has been loaded.";

            var viewModel = (DoorViewModel)DataContext;
            viewModel.ViewDoorCommand.Execute(TextBoxDoorId.Text);
        }

        private void ControlDoorClicked(object sender, RoutedEventArgs e)
        {
            TextBoxDoorId.Text = (string)DataGrid.CurrentCell.Item;
            TextBoxDoorName.Text = string.Empty;
            CheckBoxDoorOpened.IsChecked = null;
            CheckBoxDoorLocked.IsChecked = null;

            TextBoxDoorId.IsEnabled = false;
            TextBoxDoorName.IsEnabled = true;
            CheckBoxDoorOpened.IsEnabled = true;
            CheckBoxDoorLocked.IsEnabled = true;

            ButtonAddNewDoor.Visibility = Visibility.Collapsed;
            ButtonViewDoor.Visibility = Visibility.Collapsed;
            ButtonUpdateDoor.Visibility = Visibility.Visible;
            ButtonDeleteDoor.Visibility = Visibility.Collapsed;

            ButtonAddDoor.Visibility = Visibility.Collapsed;
            TextBlockStatusMessage.Text = "Door has been loaded.";

            var viewModel = (DoorViewModel) DataContext;
            viewModel.ViewDoorCommand.Execute(TextBoxDoorId.Text);
        }

        private void AddDoorClicked(object sender, RoutedEventArgs e)
        {
            TextBoxDoorId.Text = string.Empty;
            TextBoxDoorName.Text = string.Empty;
            CheckBoxDoorOpened.IsChecked = null;
            CheckBoxDoorLocked.IsChecked = null;

            TextBoxDoorId.IsEnabled = false;
            TextBoxDoorName.IsEnabled = true;
            CheckBoxDoorOpened.IsEnabled = true;
            CheckBoxDoorLocked.IsEnabled = true;

            ButtonAddNewDoor.Visibility = Visibility.Visible;
            ButtonViewDoor.Visibility = Visibility.Collapsed;
            ButtonUpdateDoor.Visibility = Visibility.Collapsed;
            ButtonDeleteDoor.Visibility = Visibility.Collapsed;

            ButtonAddDoor.Visibility = Visibility.Collapsed;
            TextBlockStatusMessage.Text = string.Empty;
        }
    }
}
